package com.oleg.latihanmvvm

class ViewModelFactory private constructor(
)